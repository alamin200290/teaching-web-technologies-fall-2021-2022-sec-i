<?php

	include('header.php');
	echo $_GET['id'];
	//delete form user.txt
	header('location: userlist.php');
?>